package com.example.ecotrack

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

class HabitAdapter(
    private val onHabitClick: (Habit) -> Unit,
    private val onItemClick: (Habit) -> Unit
) : ListAdapter<Habit, HabitAdapter.HabitViewHolder>(HabitDiffCallback()) {

    class HabitViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvTitle: TextView = view.findViewById(R.id.tvHabitTitle)
        val tvDescription: TextView = view.findViewById(R.id.tvHabitDescription)
        val checkBox: CheckBox = view.findViewById(R.id.habitCheckBox)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HabitViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_habit, parent, false)
        return HabitViewHolder(view)
    }

    override fun onBindViewHolder(holder: HabitViewHolder, position: Int) {
        val habit = getItem(position)
        holder.tvTitle.text = habit.title
        holder.tvDescription.text = habit.description

        holder.itemView.setOnClickListener {
            onItemClick(habit)
        }

        holder.checkBox.setOnCheckedChangeListener(null)
        holder.checkBox.isChecked = habit.isCompleted
        holder.checkBox.setOnCheckedChangeListener { _, isChecked ->

            val updatedHabit = habit.copy(isCompleted = isChecked)
            onHabitClick(updatedHabit)
        }
    }
    fun updateData(newHabits: List<Habit>) {
        submitList(newHabits)
    }
    class HabitDiffCallback : DiffUtil.ItemCallback<Habit>() {
        override fun areItemsTheSame(oldItem: Habit, newItem: Habit): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Habit, newItem: Habit): Boolean {
            return oldItem == newItem
        }
    }
}