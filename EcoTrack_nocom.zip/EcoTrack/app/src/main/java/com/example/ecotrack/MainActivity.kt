package com.example.ecotrack

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var habitViewModel: HabitViewModel
    private lateinit var adapter: HabitAdapter
    private lateinit var db: AppDatabase
    private var isHistoryMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = true
        db = AppDatabase.getDatabase(this)


        val dao = db.habitDao()
        val repository = HabitRepository(dao)
        val factory = HabitViewModelFactory(repository)
        habitViewModel = ViewModelProvider(this, factory).get(HabitViewModel::class.java)


        adapter = HabitAdapter(
            onHabitClick = { updatedHabit ->
                lifecycleScope.launch {

                    db.habitDao().update(updatedHabit)


                    if (updatedHabit.isCompleted) {
                        db.habitDao().trimHistory()
                    }
                }
            },
            onItemClick = { clickedHabit ->
                val intent = Intent(this, HabitDetailActivity::class.java)
                intent.putExtra("HABIT_ID", clickedHabit.id.toLong())
                startActivity(intent)
            }
        )


        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter


        val btnAdd = findViewById<FloatingActionButton>(R.id.btnAdd)
        btnAdd.setOnClickListener {
            val intent = Intent(this, AddHabitActivity::class.java)
            startActivity(intent)
        }


        val btnHistory = findViewById<Button>(R.id.btnHistory)
        btnHistory.setOnClickListener {
            isHistoryMode = !isHistoryMode
            btnHistory.text = if (isHistoryMode) "К активным" else "История"
            observeHabits()
        }

        observeHabits()
    }

    private fun observeHabits() {
        habitViewModel.allHabits.removeObservers(this)

        habitViewModel.allHabits.observe(this) { habits ->
            val filteredList = if (isHistoryMode) {

                habits.filter { it.isCompleted }
                    .sortedByDescending { it.id }
            } else {
                
                habits.filter { !it.isCompleted }
                    .sortedByDescending { it.id }
            }

            adapter.updateData(filteredList)
        }
    }
}